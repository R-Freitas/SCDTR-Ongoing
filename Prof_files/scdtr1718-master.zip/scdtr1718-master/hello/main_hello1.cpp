//main_hello1.cpp

#include "hello1.h"
#include <stdio.h>

int main()
{
   Hello1 obj;
   obj.set_id(1);
   obj.run();
   getchar();
}
