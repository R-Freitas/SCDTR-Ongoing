//hello1.h

#ifndef HELLO1_H
#define HELLO1_H

class Hello1 {
private: 
    int id;
public:
	void set_id(int);
	void run();
};

#endif //HELLO1_H
