//main_hello4.cpp

#include "hello4.h"
#include <stdio.h>

int main()
{
   Hello4 obj;
   obj.set_id(4);
   obj.run(2);
   getchar();
}
