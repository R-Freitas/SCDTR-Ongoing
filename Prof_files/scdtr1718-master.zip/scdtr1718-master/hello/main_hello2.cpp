//main_hello2.cpp

#include "hello2.h"
#include <stdio.h>

int main()
{
   Hello2 obj;
   obj.set_id(2);
   obj.run(2,3);
   getchar();
}
