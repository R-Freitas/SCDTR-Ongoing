//main_hello3.cpp

#include "hello3.h"
#include <stdio.h>

int main()
{
   Hello3 obj;
   obj.set_id(3);
   obj.run(4);
   getchar();
}
